const colours = [{
        name: "Saffron",
        value: "#f68b1f"
    },
    {
        name: "Marigold",
        value: "#f6bf2c"
    },
    {
        name: "Rose Pink",
        value: "#e84d79"
    },
    {
        name: "Leaf Green",
        value: "#54a85d"
    },
    {
        name: "Sky Blue",
        value: "#51b7df"
    },
    {
        name: "Royal Blue",
        value: "#4055b5"
    },
    {
        name: "Purple",
        value: "#8a55a2"
    },
    {
        name: "Brown",
        value: "#8c5a3c"
    },
    {
        name: "White",
        value: "#fffdf8"
    }
];

let playerName = "";
let collegeId = "";
let activeDrawing = "ganesh";
let selectedColour = colours[0];
let artwork = JSON.parse(localStorage.getItem("rangUtsavArtwork") || "{}");

const loginScreen = document.getElementById("loginScreen");
const gameScreen = document.getElementById("gameScreen");
const playerNameInput = document.getElementById("playerName");
const collegeIdInput = document.getElementById("collegeId");
const colouringCanvas = document.getElementById("colouringCanvas");
const palette = document.getElementById("palette");

const drawings = {
    ganesh: {
        title: "Ganesh Utsav Challenge",
        svg: `
      <rect width="600" height="500" fill="#fff9ed"/>
      <path class="paintable" d="M45 443 Q300 355 555 443 L555 480 L45 480Z"/>
      <path class="paintable" d="M75 430 L75 118 Q300 25 525 118 L525 430Z"/>
      <path class="paintable" d="M100 129 L145 66 L190 129 L235 66 L280 129 L325 66 L370 129 L415 66 L460 129 L505 66 L525 118 L75 118Z"/>
      <circle class="paintable" cx="127" cy="160" r="24"/>
      <circle class="paintable" cx="473" cy="160" r="24"/>
      <circle class="paintable" cx="127" cy="247" r="24"/>
      <circle class="paintable" cx="473" cy="247" r="24"/>
      <circle class="paintable" cx="127" cy="334" r="24"/>
      <circle class="paintable" cx="473" cy="334" r="24"/>
      <path class="paintable" d="M147 391 Q153 271 218 248 Q300 217 382 248 Q447 271 453 391Z"/>
      <path class="paintable" d="M227 258 Q214 165 300 120 Q386 165 373 258 Q354 314 300 325 Q246 314 227 258Z"/>
      <path class="paintable" d="M267 179 L283 102 L300 127 L317 102 L333 179Z"/>
      <path class="paintable" d="M230 246 Q165 210 172 282 Q184 340 246 306Z"/>
      <path class="paintable" d="M370 246 Q435 210 428 282 Q416 340 354 306Z"/>
      <path class="paintable" d="M273 286 Q300 297 327 286 L317 379 Q300 406 283 379Z"/>
      <circle class="paintable" cx="269" cy="226" r="10"/>
      <circle class="paintable" cx="331" cy="226" r="10"/>
      <path class="paintable" d="M194 363 Q225 337 255 369 L245 419 L191 419Z"/>
      <path class="paintable" d="M406 363 Q375 337 345 369 L355 419 L409 419Z"/>
      <circle class="paintable" cx="218" cy="393" r="16"/>
      <circle class="paintable" cx="382" cy="393" r="16"/>
      <path class="paintable" d="M264 349 Q300 333 336 349 L343 391 Q300 414 257 391Z"/>
      <circle class="paintable" cx="300" cy="82" r="28"/>
      <text x="300" y="496" text-anchor="middle" font-family="Poppins" font-size="14" fill="#78502b">Ganesh Utsav Challenge</text>
    `
    },

    nature: {
        title: "Nature Garden Challenge",
        svg: `
      <rect width="600" height="500" fill="#fff9ed"/>
      <path class="paintable" d="M0 407 Q100 367 199 407 Q337 350 600 395 L600 500 L0 500Z"/>
      <circle class="paintable" cx="510" cy="75" r="40"/>
      <path class="paintable" d="M280 416 L290 179 L311 179 L321 416Z"/>
      <path class="paintable" d="M301 192 Q244 135 190 163 Q205 224 274 230 Q222 226 183 275 Q225 323 287 292 Q228 309 222 365 Q265 389 301 334Z"/>
      <path class="paintable" d="M301 192 Q358 135 412 163 Q397 224 328 230 Q380 226 419 275 Q377 323 315 292 Q374 309 380 365 Q337 389 301 334Z"/>
      <path class="paintable" d="M71 409 Q66 327 122 303 Q183 299 210 349 Q206 395 184 409Z"/>
      <path class="paintable" d="M530 409 Q534 327 478 303 Q417 299 390 349 Q394 395 416 409Z"/>
      <path class="paintable" d="M82 427 Q86 380 132 379 Q178 380 183 427Z"/>
      <path class="paintable" d="M418 427 Q422 380 468 379 Q514 380 518 427Z"/>
      <circle class="paintable" cx="130" cy="348" r="22"/>
      <circle class="paintable" cx="470" cy="348" r="22"/>
      <circle class="paintable" cx="94" cy="320" r="16"/>
      <circle class="paintable" cx="507" cy="320" r="16"/>
      <path class="paintable" d="M30 448 Q61 401 91 448 Q64 473 30 448Z"/>
      <path class="paintable" d="M509 448 Q539 401 570 448 Q540 473 509 448Z"/>
      <path class="paintable" d="M96 111 Q122 77 148 111 Q122 145 96 111Z"/>
      <path class="paintable" d="M151 89 Q177 55 203 89 Q177 123 151 89Z"/>
      <path class="paintable" d="M206 117 Q232 83 258 117 Q232 151 206 117Z"/>
      <path class="paintable" d="M356 93 Q382 59 408 93 Q382 127 356 93Z"/>
      <path class="paintable" d="M412 120 Q438 86 464 120 Q438 154 412 120Z"/>
      <text x="300" y="490" text-anchor="middle" font-family="Poppins" font-size="14" fill="#78502b">Nature Garden Challenge</text>
    `
    },

    peacock: {
        title: "Royal Peacock Challenge",
        svg: `
      <rect width="600" height="500" fill="#fff9ed"/>
      <path class="paintable" d="M54 420 Q35 192 190 79 Q300 10 410 79 Q565 192 546 420Z"/>
      <path class="paintable" d="M102 403 Q91 219 200 128 Q300 60 400 128 Q509 219 498 403Z"/>
      <ellipse class="paintable" cx="174" cy="178" rx="35" ry="50"/>
      <ellipse class="paintable" cx="300" cy="106" rx="35" ry="50"/>
      <ellipse class="paintable" cx="426" cy="178" rx="35" ry="50"/>
      <ellipse class="paintable" cx="120" cy="290" rx="35" ry="50"/>
      <ellipse class="paintable" cx="226" cy="272" rx="35" ry="50"/>
      <ellipse class="paintable" cx="374" cy="272" rx="35" ry="50"/>
      <ellipse class="paintable" cx="480" cy="290" rx="35" ry="50"/>
      <circle class="paintable" cx="174" cy="178" r="15"/>
      <circle class="paintable" cx="300" cy="106" r="15"/>
      <circle class="paintable" cx="426" cy="178" r="15"/>
      <circle class="paintable" cx="120" cy="290" r="15"/>
      <circle class="paintable" cx="226" cy="272" r="15"/>
      <circle class="paintable" cx="374" cy="272" r="15"/>
      <circle class="paintable" cx="480" cy="290" r="15"/>
      <path class="paintable" d="M280 418 Q242 290 282 203 Q326 174 361 219 Q390 299 346 418Z"/>
      <path class="paintable" d="M289 232 Q276 166 306 132 Q344 123 360 160 Q366 204 339 230Z"/>
      <path class="paintable" d="M307 142 L297 83 L322 117 L339 75 L347 147Z"/>
      <path class="paintable" d="M358 165 L420 185 L360 198Z"/>
      <circle class="paintable" cx="330" cy="164" r="8"/>
      <path class="paintable" d="M242 415 L277 415 L258 462 L227 462Z"/>
      <path class="paintable" d="M326 415 L355 415 L373 462 L342 462Z"/>
      <text x="300" y="490" text-anchor="middle" font-family="Poppins" font-size="14" fill="#78502b">Royal Peacock Challenge</text>
    `
    }
};

document.getElementById("startBtn").addEventListener("click", login);

document.getElementById("logoutBtn").addEventListener("click", () => {
    gameScreen.classList.add("hidden");
    loginScreen.classList.remove("hidden");
    playerNameInput.focus();
});

document.querySelectorAll(".drawing-choice").forEach((button) => {
    button.addEventListener("click", () => {
        document.querySelector(".drawing-choice.active").classList.remove("active");
        button.classList.add("active");
        activeDrawing = button.dataset.drawing;
        loadDrawing(activeDrawing);
    });
});

function login() {
    playerName = playerNameInput.value.trim();
    collegeId = collegeIdInput.value.trim().toUpperCase();
    const error = document.getElementById("loginError");

    if (playerName.length < 2) {
        error.textContent = "Please enter your name.";
        return;
    }

    if (collegeId.length < 4) {
        error.textContent = "Please enter a valid College ID number.";
        return;
    }

    error.textContent = "";
    document.getElementById("welcomeName").textContent = playerName.toUpperCase();
    loginScreen.classList.add("hidden");
    gameScreen.classList.remove("hidden");

    renderPalette();
    loadDrawing(activeDrawing);
    renderLeaderboard();
}

function renderPalette() {
    palette.innerHTML = "";

    colours.forEach((colour) => {
        const button = document.createElement("button");
        button.className = "colour-dot";
        button.title = colour.name;
        button.style.background = colour.value;

        if (colour.value === selectedColour.value) {
            button.classList.add("active");
        }

        button.addEventListener("click", () => {
            selectedColour = colour;
            document.getElementById("selectedColourName").textContent = colour.name;
            renderPalette();
        });

        palette.appendChild(button);
    });
}

function loadDrawing(drawingKey) {
    const drawing = drawings[drawingKey];
    document.getElementById("drawingTitle").textContent = drawing.title;
    colouringCanvas.innerHTML = drawing.svg;

    const savedColours = artwork[collegeId]?. [drawingKey]?.colours || {};

    colouringCanvas.querySelectorAll(".paintable").forEach((part, index) => {
        if (savedColours[index]) {
            part.style.fill = savedColours[index];
        }

        part.addEventListener("click", () => {
            part.style.fill = selectedColour.value;
            updateScore();
        });
    });

    updateScore();
}

function getArtworkScore() {
    const parts = [...colouringCanvas.querySelectorAll(".paintable")];

    const paintedParts = parts.filter((part) => {
        return part.style.fill &&
            part.style.fill !== "rgb(255, 253, 248)" &&
            part.style.fill !== "#fffdf8";
    });

    const coloursUsed = new Set(paintedParts.map((part) => part.style.fill)).size;
    const completionScore = Math.round((paintedParts.length / parts.length) * 75);
    const creativityScore = Math.min(coloursUsed * 3, 25);

    return Math.min(100, completionScore + creativityScore);
}

function updateScore() {
    document.getElementById("currentScore").textContent = getArtworkScore();
}

document.getElementById("submitBtn").addEventListener("click", () => {
    const score = getArtworkScore();

    if (score === 0) {
        showToast("Please colour part of the drawing before saving.");
        return;
    }

    const paintedColours = {};

    [...colouringCanvas.querySelectorAll(".paintable")].forEach((part, index) => {
        if (part.style.fill) {
            paintedColours[index] = part.style.fill;
        }
    });

    if (!artwork[collegeId]) {
        artwork[collegeId] = {};
    }

    artwork[collegeId][activeDrawing] = {
        name: playerName,
        collegeId: collegeId,
        score: score,
        colours: paintedColours,
        updatedAt: Date.now()
    };

    localStorage.setItem("rangUtsavArtwork", JSON.stringify(artwork));
    renderLeaderboard();
    showToast(`Artwork saved successfully! Score: ${score}`);
});

function renderLeaderboard() {
    const allScores = [];

    Object.keys(artwork).forEach((id) => {
        Object.keys(artwork[id]).forEach((drawingKey) => {
            const entry = artwork[id][drawingKey];

            allScores.push({
                name: entry.name,
                collegeId: entry.collegeId,
                drawing: drawings[drawingKey].title,
                score: entry.score
            });
        });
    });

    allScores.sort((a, b) => b.score - a.score);

    const list = document.getElementById("leaderboardList");
    list.innerHTML = "";

    if (allScores.length === 0) {
        list.innerHTML = `<li class="empty-board">No artwork saved yet. Be the first artist!</li>`;
        return;
    }

    allScores.slice(0, 10).forEach((entry) => {
        const item = document.createElement("li");
        item.innerHTML = `
      ${escapeHtml(entry.name)}
      <br><small>ID: ${escapeHtml(entry.collegeId)}</small>
      <br><small>${escapeHtml(entry.drawing)}</small>
      <span>${entry.score}</span>
    `;
        list.appendChild(item);
    });
}

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}

function showToast(message) {
    const toast = document.getElementById("toast");
    toast.textContent = message;
    toast.classList.add("show");

    setTimeout(() => {
        toast.classList.remove("show");
    }, 2600);
}